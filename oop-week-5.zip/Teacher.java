// createed by team in Bangalore
public class Teacher {
    // data
    private String name;
    private String ic;
    private String address;
    private int numyearexp;
    private String qualification;
    
    // op
    
    
}